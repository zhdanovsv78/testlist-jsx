import GetElement from './components/element';

function App() {
  return (
	<>
	<GetElement />
	</>
  );
}

export default App;
