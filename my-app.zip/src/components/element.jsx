import React from "react"
import { useState } from "react"
import { getUsers } from "../api.js"

// функция-компонент
const GetElement = () => {
	
	const [users, setUsers] = useState(getUsers())
	
	// const getArr = (arr) => {
	// 	console.log(arr)
	// }

	function func(qualities) {
		console.log(qualities)
	}

	return(
		
		<>
		<h1>Привет</h1>
		
		<ul>{
				users.map(user => 
					<li key={user._id}>
						<span class="bedge bg-primary p-1">Имя:</span> 
							{user.name}, 
						<span class="bedge bg-primary p-1">Количество встреч:</span>
							{user.completedMeetings}, 
						<span class="bedge bg-primary p-1">Рейтинг:</span>
							{user.rate}
						<span class="bedge bg-primary p-1">Профессия:</span>
							{user.profession["_id"]}, {user.profession["name"]}

						<span class="bedge bg-primary p-1">Качества:</span>
						
						func({user.qualities})
							
					</li>
				)
			}
		</ul>
		
		
		</>

		
		
	)
}

export default GetElement